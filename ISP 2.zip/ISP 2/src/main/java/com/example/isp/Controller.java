
package com.example.isp;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.util.Callback;

import java.sql.*;
import java.util.ArrayList;

public class Controller {

    @FXML
    private ChoiceBox<String> cbSpeed;
    @FXML
    private ChoiceBox<String> cbBandwidth;
    @FXML
    private ChoiceBox<String> cbDuration;
    @FXML
    private TextField tfFullName;
    @FXML
    private TextField tfAddress;
    @FXML
    private ListView<Model> listView;

    private final ObservableList<Model> customersList = FXCollections.observableArrayList();


    @FXML
    private void initialize() {
        // Add string representations of integers to the ChoiceBoxes
        cbSpeed.getItems().addAll("2", "5", "10", "20", "50", "100");
        cbBandwidth.getItems().addAll("1", "5", "10", "100", "Flat");
        cbDuration.getItems().addAll("1", "2");

        listView.setItems(customersList);

        listView.setCellFactory(new Callback<ListView<Model>, ListCell<Model>>() {
            @Override
            public ListCell<Model> call(ListView<Model> param) {
                return new ListCell<Model>() {
                    @Override
                    protected void updateItem(Model item, boolean empty) {
                        super.updateItem(item, empty);
                        if (empty || item == null) {
                            setText(null);
                        } else {
                            // Customize the display of each item here
                            setText("Full Name: " + item.getFullName() + "\nAddress: " + item.getAddress() + "\nSpeed: " + item.getSpeed() +"   (mb/s)" + "\nDuration: " + item.getDuration() +  "  Year/s" + "\nBandwidth: " + item.getBandwidth());
                            setStyle("-fx-padding: 10px;");
                        }
                    }
                };
            }
        });

        fetchCustomersData();
    }

    private void fetchCustomersData() {
        try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/isp2", "root", "password");
             PreparedStatement st = conn.prepareStatement("SELECT * FROM package");
             ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                Model customer = new Model();
                customer.setId(rs.getInt("packageId"));
                customer.setFullName(rs.getString("fullName"));
                customer.setAddress(rs.getString("address"));
                customer.setDuration(rs.getInt("duration"));
                customer.setSpeed(rs.getInt("speed"));
                customer.setBandwidth(rs.getString("bandwidth"));
                customersList.add(customer);
            }

        } catch (SQLException e) {
            showErrorAlert("SQL Error: " + e.getMessage());
        }
    }

    private void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void deleteCustomer() {
        Model selectedCustomer = listView.getSelectionModel().getSelectedItem();
        if (selectedCustomer != null) {
            int customerId = selectedCustomer.getId();
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/isp2", "root", "password");
                 PreparedStatement st = conn.prepareStatement("DELETE FROM package WHERE packageId = ?")) {

                st.setInt(1, customerId);
                int rowsAffected = st.executeUpdate();
                if (rowsAffected > 0) {
                    customersList.remove(selectedCustomer);
                } else {
                    showErrorAlert("Failed to delete customer.");
                }

            } catch (SQLException e) {
                showErrorAlert("SQL Error: " + e.getMessage());
            }
        } else {
            showErrorAlert("Please select a customer to delete.");
        }
    }

    @FXML
    private void sell() {
        Model customer = new Model();

        int speedValue = Integer.parseInt(cbSpeed.getValue());
        customer.setSpeed(speedValue);

        int durationValue = Integer.parseInt(cbDuration.getValue());
        customer.setDuration(durationValue);

        customer.setFullName(tfFullName.getText());
        customer.setAddress(tfAddress.getText());

        String bandwidthValue = cbBandwidth.getValue();
        if (bandwidthValue == null || bandwidthValue.isEmpty() || bandwidthValue.equals("Select")) {
            showErrorAlert("You must select Bandwidth.");
            return;
        }

        customer.setBandwidth(bandwidthValue);

        if (customer.isValid()) {
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/isp2", "root", "password");
                 PreparedStatement st = conn.prepareStatement("INSERT INTO package (fullName, address, duration, speed, bandwidth) VALUES (?, ?, ?, ?, ?)",
                         Statement.RETURN_GENERATED_KEYS)) {

                st.setString(1, customer.getFullName());
                st.setString(2, customer.getAddress());
                st.setInt(3, customer.getDuration());
                st.setInt(4, customer.getSpeed());
                st.setString(5, customer.getBandwidth());

                int rowsAffected = st.executeUpdate();

                if (rowsAffected > 0) {
                    ResultSet generatedKeys = st.getGeneratedKeys();
                    if (generatedKeys.next()) {
                        customer.setId(generatedKeys.getInt(1));
                        customersList.add(customer);
                    }
                } else {
                    showErrorAlert("Failed to save customer.");
                }

            } catch (SQLException e) {
                showErrorAlert("SQL Error: " + e.getMessage());
            }
        } else {
            StringBuilder errMsg = new StringBuilder();
            ArrayList<String> errList = customer.errorsProperty().get();
            for (String error : errList) {
                errMsg.append(error).append("\n");
            }
            showErrorAlert(errMsg.toString());
        }
    }
}
