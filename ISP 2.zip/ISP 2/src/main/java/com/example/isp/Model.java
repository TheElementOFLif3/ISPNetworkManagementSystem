package com.example.isp;

import javafx.beans.property.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;


public class Model {

    private final IntegerProperty speed = new SimpleIntegerProperty(this, "speed");
    private final ObjectProperty<Object> bandwidth = new SimpleObjectProperty<>(this, "bandwidth");
    private final IntegerProperty duration = new SimpleIntegerProperty(this, "duration");
    private final IntegerProperty id = new SimpleIntegerProperty(this, "id");
    private final StringProperty fullName = new SimpleStringProperty(this, "fullName");
    private final StringProperty address = new SimpleStringProperty(this, "address");
    private final ObjectProperty<ArrayList<String>> errorList = new SimpleObjectProperty<>(this, "errorList", new ArrayList<>());

    public Model() {
    }

    public int getSpeed() {
        return speed.get();
    }

    public void setSpeed(int speed) {
        this.speed.set(speed);
    }

    public IntegerProperty speedProperty() {
        return speed;
    }

    public String getBandwidth() {
        return (String) bandwidth.get();
    }

    public void setBandwidth(Object bandwidth) {
        this.bandwidth.set(bandwidth);
    }

    public ObjectProperty<Object> bandwidthProperty() {
        return bandwidth;
    }

    public int getDuration() {
        return duration.get();
    }

    public void setDuration(int duration) {
        this.duration.set(duration);
    }

    public IntegerProperty durationProperty() {
        return duration;
    }

    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    public String getFullName() {
        return fullName.get();
    }

    public void setFullName(String fullName) {
        this.fullName.set(fullName);
    }

    public StringProperty fullNameProperty() {
        return fullName;
    }

    public String getAddress() {
        return address.get();
    }

    public void setAddress(String address) {
        this.address.set(address);
    }

    public StringProperty addressProperty() {
        return address;
    }

    public ObjectProperty<ArrayList<String>> errorsProperty() {
        return errorList;
    }

    public boolean isValid() {
        boolean isValid = true;

        if (fullName.get() == null || fullName.get().isEmpty()) {
            errorList.getValue().add("Full name must be entered!");
            isValid = false;
        }
        if (address.get() == null || address.get().isEmpty()) {
            errorList.getValue().add("Address must be entered!");
            isValid = false;
        }
        if (bandwidth.get() == null) {
            errorList.getValue().add("Bandwidth must be selected!");
            isValid = false;
        }
        if (duration.get() == 0) {
            errorList.getValue().add("Contract duration must be specified!");
            isValid = false;
        }
        if (speed.get() == 0) {
            errorList.getValue().add("Speed must be selected!");
            isValid = false;
        }
        return isValid;
    }

    public void save() throws ClassNotFoundException, SQLException {
        if (isValid()) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/isp2", "root", "password")) {
                PreparedStatement st = conn.prepareStatement("INSERT INTO package (fullName, address, duration, speed, bandwidth) VALUES (?, ?, ?, ?, ?)");
                st.setString(1, fullName.get());
                st.setString(2, address.get());
                st.setInt(3, duration.get());
                st.setInt(4, speed.get());
                st.setObject(5, bandwidth.get());
                st.executeUpdate();
            }
        }
    }
}
